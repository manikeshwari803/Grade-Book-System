create database GradebookSystem;
use GradebookSystem;
create table student(s_id int primary key,s_name varchar(40), email varchar(100));
insert into student(s_id,s_name,email) values (111,'Sampreet','sampreet@gmail.com'),(112,'Vaishnavi','vaishnavi@gmail.com'),(113,'Laxmi','laxmi@gmail.com'),(114,'Pari','pari@gmail.com'),(115,'Abhishek','abhi@gmail.com'),(116,'Manu','manu@gmail.com'),(117,'Pinku','pinku@gmail.com'),(118,'Jagu','jagu@gmail.com'),(119,'Seenu','seenu@gmail.com'),(210,'Aruna','aruna@gmail.com');
select * from student;
create table courses(c_id int primary key,c_name varchar(100));
insert into courses(c_id,c_name)values(101,'Mathematics'),(102,'Biology'),(103,'Social'),(104,'English'),(105,'Kannada'),(106,'Hindi'),(107,'Computer science'),(108,'Electronics'),(109,'Chemistry'),(110,'Physics');
select * from courses;
create table assignments(a_id int primary key, a_name varchar(100),maxscore int,c_id int,constraint M_foreignkey foreign key (c_id) references courses(c_id));
insert into assignments(a_id,a_name,maxscore,c_id) values ( 1, 'a1',100,101),(2,'a2',100,102),(3,'a3',100,103),(4,'a4',100,104),(5,'a5',100,105),(6,'a6',100,106),(7,'a7',100,107),(8,'a8',100,108),(9,'a9',100,109),(10,'a10',100,110);
select * from assignments;
create table grades(g_id int primary key,score int,s_id int,constraint S_foreignkey foreign key(s_id) references student(s_id),a_id int,constraint A_foreignkey foreign key(a_id) references assignments(a_id));
insert into grades(g_id,score,s_id,a_id) values (11,75,111,1),(12,85,112,2),(13,78,113,3),(14,95,114,4),(15,98,115,5),(16,93,116,6),(17,88,117,7),(18, 45,118,8),(19,55,119,9),(20,50,210,10);
select * from grades;
/**Update Student Email:**/
UPDATE student SET email = 'rahul123@gmail.com' WHERE s_id = 120;
/** like function**/
SELECT s_name, email
FROM student
WHERE s_name LIKE 'A%';

/** gives 101 id value**/
SELECT s.s_name, s.email
FROM student s
JOIN grades g ON s.s_id = g.s_id
JOIN assignments a ON g.a_id = a.a_id
WHERE a.c_id = 101; 
/** gives students list who ever has morethan 90**/
SELECT s.s_name, s.email, g.score
FROM student s
JOIN grades g ON s.s_id = g.s_id
WHERE g.score > 90;
/**Retrieve Students with Scores Between 80 and 90**/
SELECT s_name, email
FROM student s
JOIN grades g ON s.s_id = g.s_id
WHERE g.score BETWEEN 80 AND 90;

/**Calculate Average Score per Course**/
SELECT c.c_name, AVG(g.score) AS average_score
FROM courses c
JOIN assignments a ON c.c_id = a.c_id
JOIN grades g ON a.a_id = g.a_id
GROUP BY c.c_name;
/**Subquery**/
/**Find Students who didn't Submit Assignment 'a1'**/
SELECT s_name, email
FROM student
WHERE s_id NOT IN (SELECT s_id FROM grades WHERE a_id = 1);
/** it wil give list of students who have not submitted the assignment
SELECT s.s_name, s.email
FROM student s
LEFT JOIN grades g ON s.s_id = g.s_id
WHERE g.s_id IS NULL;
**/
/**gives a2 values**/
SELECT s.s_name, s.email, g.score, a.maxscore, (g.score / a.maxscore) * 100 AS percentage
FROM student s
JOIN grades g ON s.s_id = g.s_id
JOIN assignments a ON g.a_id = a.a_id
WHERE a.a_name = 'a2';
/**Display Students who Scored Below 60 in Chemistry or Physics**/
SELECT s_name, email
FROM student s
JOIN grades g ON s.s_id = g.s_id
JOIN assignments a ON g.a_id = a.a_id
JOIN courses c ON a.c_id = c.c_id
WHERE (c.c_name = 'Chemistry' OR c.c_name = 'Physics') AND g.score < 60;


